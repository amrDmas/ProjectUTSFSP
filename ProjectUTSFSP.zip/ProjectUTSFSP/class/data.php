<?php
    define("SERVER", "localhost");
    define("DB", "esport_db");
    define("USER", "root");
    define("PASS", "");
?>